package org.levi9.model;

public enum StatusOfConfiguration {
	CREATED, CHECKEDOUT, PAID, DELIVERED
}
