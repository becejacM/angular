package org.levi9.model;

public class Role {
	public static final String ADMIN = "ADMIN";
	public static final String USER = "USER";
}
